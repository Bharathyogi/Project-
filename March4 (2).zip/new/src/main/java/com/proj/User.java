package com.proj;

public class User {
	 String name;
	 String branch;
	 String contact;
	 String email;
	 String username;
	 String codeid;
	public User(String name, String branch, String contact, String email, String username, String codeid) {
		super();
		this.name = name;
		this.branch = branch;
		this.contact = contact;
		this.email = email;
		this.username = username;
		this.codeid = codeid;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCodeid() {
		return codeid;
	}

	public void setCodeid(String codeid) {
		this.codeid = codeid;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", branch=" + branch + ", contact=" + contact + ", email=" + email + ", username="
				+ username + ", codeid=" + codeid + "]";
	}
	 
}
