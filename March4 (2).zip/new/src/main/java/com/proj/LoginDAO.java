package com.proj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
//import java.util.ArrayList;
//import java.util.List;



public class LoginDAO {

	
	public String validate(String uname,String pass) {
		
		Connection con = null;
		String password = null;
		String name = null;
		String result=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT passWord,Student_Name FROM user_details WHERE userName='"+uname+"'");
			
			while(rs.next()) {
				password=rs.getString(1);
				name=rs.getString(2);
			}
			
			if(password.equals(pass)) {
				result=name;

			}else {
				result=null;
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		
		return result;
	}
	
public String validate_admin(String uname,String pass) {
		
		Connection con = null;
		String password = null;
		String name = null;
		String result=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT passWord,userName FROM admin_login WHERE userName='"+uname+"'");
			
			while(rs.next()) {
				password=rs.getString(1);
				name=rs.getString(2);
			}
			
			if(password.equals(pass)) {
				result=name;

			}else {
				result=null;
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		
		return result;
	}
	
	public String userBranch(String uname) {
		Connection con= null;
		String result=null;
		String branch=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			ResultSet rs=st.executeQuery("SELECT branch FROM user_details WHERE userName='"+uname+"'");
			
			while(rs.next()) {
				branch=rs.getString(1);
			}
			result=branch;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		return result;
		
	}
	
	public String userName(String uname) {
		Connection con= null;
		String result=null;
		String branch=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			ResultSet rs=st.executeQuery("SELECT Student_Name FROM user_details WHERE userName='"+uname+"'");
			
			while(rs.next()) {
				branch=rs.getString(1);
			}
			result=branch;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		return result;
		
	}
	
	public String userContact(String uname) {
		Connection con= null;
		String result=null;
		String branch=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			ResultSet rs=st.executeQuery("SELECT Contact FROM user_details WHERE userName='"+uname+"'");
			
			while(rs.next()) {
				branch=rs.getString(1);
			}
			result=branch;
			System.out.println(branch);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		return result;
		
	}
	public String userEmail(String uname) {
		Connection con= null;
		String result=null;
		String branch=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			ResultSet rs=st.executeQuery("SELECT Email FROM user_details WHERE userName='"+uname+"'");
			
			while(rs.next()) {
				branch=rs.getString(1);
			}
			result=branch;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		return result;
		
	}
	
	public String userCode(String uname) {
		Connection con= null;
		String result=null;
		String branch=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			ResultSet rs=st.executeQuery("SELECT codeid FROM admin_box WHERE userName='"+uname+"'");
			
			while(rs.next()) {
				branch=rs.getString(1);
			}
			
			result=branch;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		return result;
	}
	
	
	public List<User> selectAllUsers() {
		Connection con= null;

		// using try-with-resources to avoid closing resources (boiler plate code)
		ArrayList<User> users = new ArrayList<User>();
		// Step 1: Establishing a Connection
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db", "root", "Sa@251138148");
			Statement st=con.createStatement();
			
			ResultSet rs=st.executeQuery("SELECT * FROM admin_box");

		 // Step 4: Process the ResultSet object.
			while (rs.next()) {
				String name = rs.getString("Student_Name");
				String branch= rs.getString("Branch");
				String contact = rs.getString("Contact");
				String email = rs.getString("Email");
				String username = rs.getString("userName");
				String codeid = rs.getString("codeid");
				users.add(new User(name, branch, contact, email, username, codeid));
				}
			}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			} finally {
	
			 try {
				if (con != null) {
				con.close();
				}
				} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}

		 }
		System.out.println(users);
		return users;
		}
	 
	
	
	public String codeId(String name,String branch,String contact,String email,String uname, String id) {
		String codeid;
		
		codeid=branch+uname+"-"+id;
		Connection con= null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			int i=st.executeUpdate("insert into admin_box values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+uname+"','"+codeid+"')");  
			System.out.println(i);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		
		
		return codeid;
	}
	public String userRegistration(String name, String branch, String contact, String email, String userName,
			String password) {
		
		Connection con= null;
		String result=null;
		if(!validateUname(userName)) {
			
			System.out.println("Result ::"+result);
			return result;
		}
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			int i=st.executeUpdate("insert into user_details(Student_Name,Branch,Contact,Email,userName,passWord) values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");  
			System.out.println("i ::"+i);
			if(i>0) {
			result =name;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		
		System.out.println("Result ::"+result);
		return result;

	}
	public boolean validateUname(String uname) {
		Connection con= null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT userName FROM user_details ");
			
			while(rs.next()) {
				
				if(uname.equals(rs.getString(1))) 
					return false;
			}
			return true;	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		
	}

	}

	public String userno(String userName) {
		Connection con= null;
		String result=null;
		String branch=null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			ResultSet rs=st.executeQuery("SELECT UserNo FROM user_details WHERE userName='"+userName+"'");
			
			while(rs.next()) {
				branch=rs.getString(1);
			}
			
			result=branch;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		return result;
	}

	public String addingbook(String name, String Category, String author) {
		
		Connection con= null;
		String result=null;
		if(!validatebook(name)) {
			
			System.out.println("Result ::"+result);
			return result;
		}
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
//			System.out.println("insert into user_details values('"+name+"','"+branch+"','"+contact+"','"+email+"','"+userName+"','"+password+"')");
			int i=st.executeUpdate("insert into add_book(name,Category,author) values('"+name+"','"+Category+"','"+author+"')");  
			System.out.println("i ::"+i);
			if(i>0) {
			result =name;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		
		System.out.println("Result ::"+result);
		return result;
		
		
		
	}
	public boolean validatebook(String name) {
		Connection con= null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/new_db?autoReconnect=true&useSSL=false", "root", "Sa@251138148");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("SELECT name FROM add_book ");
			
			while(rs.next()) {
				
				if(name.equals(rs.getString(1))) 
					return false;
			}
			return true;	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		
		}

	}
}
