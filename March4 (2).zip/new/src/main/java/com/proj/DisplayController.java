package com.proj;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DisplayController {
	
	LoginDAO dao=new LoginDAO();
	
	@RequestMapping("/login")
	public ModelAndView loginUser(HttpServletRequest req,HttpServletResponse res) {
		
	String uname= req.getParameter("u");
	String pass=req.getParameter("p");
	  String result=dao.validate(uname, pass);
	  String branch=dao.userBranch(uname);
	  String email=dao.userEmail(uname);
	  String contact=dao.userContact(uname);
	  String CodeID=dao.userCode(uname);
	  String name=dao.userName(uname);
	
	ModelAndView mv= new ModelAndView();
	
	
	if(result!=null) {
	mv.setViewName("Home.jsp");
	mv.addObject("name", name);
	mv.addObject("branch", branch);
	mv.addObject("email", email);
	mv.addObject("contact", contact);
	mv.addObject("CodeID", CodeID);
	
	}else {
		mv.setViewName("index1.jsp");
	}
  //  mv.addObject("name", result);
		
	return mv;
	
	}
	
	
	
	  @RequestMapping("/admin_login") public ModelAndView
	  admin_login(HttpServletRequest req,HttpServletResponse res) throws
	  ServletException, IOException {
	  
	  String uname= req.getParameter("u"); String pass=req.getParameter("p");
	  String result=dao.validate_admin(uname, pass);
	  
	  
	  ModelAndView mv= new ModelAndView();
	  
	  if(result!=null) { 
		  List<User> listUser = dao.selectAllUsers();
//	  req.setAttribute("listUser", listUser); RequestDispatcher dispatcher =
//	  req.getRequestDispatcher("Home1.jsp"); dispatcher.forward(req, res); 
	  mv.setViewName("Home1.jsp");
	  Iterator itr=listUser.iterator();
	 while(itr.hasNext()){
	 User us=(User)itr.next();
	 mv.addObject("name", us.name);
	 mv.addObject("branch", us.branch);
	 mv.addObject("contact", us.contact);
	 mv.addObject("email", us.email);
	 mv.addObject("username", us.username);
	 mv.addObject("codeid", us.codeid);
	 System.out.println(us);
	 System.out.println(listUser);
	 mv.addObject("us",us);
	 }
	  }
	  else 
	  { 
		  mv.setViewName("index3.jsp"); 
		  } 
	  // mv.addObject("name", result);
	  
	  return mv;
	  
	  }
	  
	  
	  @RequestMapping("/AddBook") 
	  public ModelAndView AddBook(HttpServletRequest req,HttpServletResponse res) throws
	  ServletException, IOException {
		    String name= req.getParameter("name");
			String Category=req.getParameter("Category");
			String author= req.getParameter("author");
			
			name=name.trim();
			author=author.trim();
			
			String uname=dao.addingbook(name, Category, author);
			
			
			ModelAndView mv= new ModelAndView();
			if(uname!=null) {
				mv.setViewName("Home1.jsp");
				
			}
			
			else {
				mv.setViewName("ErrAddBook.jsp");
			}
		  //  mv.addObject("name", result);
			
			return mv;
	  
	  
	  }
	 
	
	@RequestMapping("/register")
	public ModelAndView userRegistration(HttpServletRequest req,HttpServletResponse res) {
		
		String name= req.getParameter("name");
		String branch=req.getParameter("branch");
		String contact= req.getParameter("contact");
		String email= req.getParameter("email");
		String userName= req.getParameter("userName");
		String password= req.getParameter("password");
		name=name.trim();
		
		String uname=dao.userRegistration(name, branch, contact, email, userName, password);
		String no=dao.userno(userName);
		String CodeID=dao.codeId(name, branch, contact, email, userName, no);
		
		ModelAndView mv= new ModelAndView();
		if(uname!=null) {
			mv.setViewName("Home.jsp");
			mv.addObject("name", name);
			mv.addObject("branch", branch);
			mv.addObject("email", email);
			mv.addObject("contact", contact);
			mv.addObject("CodeID", CodeID);
		}
		
		else {
			mv.setViewName("Registration2.jsp");
		}
	  //  mv.addObject("name", result);
		
		return mv;
	}
	
}
